#!/bin/bash

# Set directories relative to the current working directory
alignment_dir="$(pwd)"  # Current directory where the _aln files are located
script_dir="$(dirname "$(realpath "$0")")"  # Directory where the script is located
parent_script_dir="$(dirname "$script_dir")"  # One level up from the script directory
fasta_dir="$(dirname "$(dirname "$alignment_dir")")"  # Two levels up for the .fasta file
output_dir="$alignment_dir"
summary_file="${output_dir}/summary_hhmer.txt"

# Debugging information
echo "DEBUG: Alignment directory: $alignment_dir"
echo "DEBUG: FASTA directory: $fasta_dir"
echo "DEBUG: Script directory: $script_dir"
echo "DEBUG: Parent Script Directory: $parent_script_dir"
echo "DEBUG: Output directory: $output_dir"
echo "DEBUG: Summary file: $summary_file"

# Step 1: Clean up previous run files except .sh and _aln.fasta
echo "Cleaning up old files..."
find "$output_dir" -type f ! -name '*.sh' ! -name '*_aln.fasta' -exec rm -f {} +

# Step 2: Build HMM profiles for each alignment
echo "Building HMM profiles..." | tee "$summary_file"
for alignment_file in "$alignment_dir"/*.fasta; do
    base_name=$(basename "$alignment_file" .fasta)
    hmm_file="${output_dir}/${base_name}.hmm"
    echo "Building HMM profile for $alignment_file -> $hmm_file" | tee -a "$summary_file"
    hmmbuild "$hmm_file" "$alignment_file"
done

echo "HMM profiles built successfully." | tee -a "$summary_file"

# Step 3: Search each HMM profile against the provided FASTA file
fasta_files=("$fasta_dir"/*.fasta)  # Dynamically find .fasta file two levels up
if [ -z "${fasta_files[0]}" ]; then
    echo "ERROR: No .fasta file found two levels up in $fasta_dir"
    exit 1
fi
fasta_file="${fasta_files[0]}"

echo "Using FASTA file: $fasta_file"

echo "Running hmmsearch and compiling results into summary file..." | tee -a "$summary_file"
for hmm_file in "$output_dir"/*.hmm; do
    hmm_name=$(basename "$hmm_file" .hmm)
    output_file="${output_dir}/${hmm_name}_hmmsearch.out"
    echo "Running hmmsearch for $hmm_file against $fasta_file..." | tee -a "$summary_file"
    hmmsearch --tblout "$output_file" "$hmm_file" "$fasta_file"
    hits=$(grep -v "^#" "$output_file" | awk '{print $1}')
    if [ -n "$hits" ]; then
        echo -e "\nFamily: $hmm_name - Matched transcripts:" | tee -a "$summary_file"
        echo "$hits" | tr ',' '\n' > "${output_dir}/${hmm_name}_grep.txt"
    else
        echo -e "\nFamily: $hmm_name - No matches found" | tee -a "$summary_file"
        echo "No matches found" > "${output_dir}/${hmm_name}_grep.txt"
    fi
done

# Step 4: Concatenate all the _grep.txt files into a single tabular format
echo "Creating tabular format..."
header=$(ls "${output_dir}"/*_grep.txt | xargs -n1 basename | sed 's/_grep.txt//' | tr '\n' '\t')
echo -e "${header}" > "${output_dir}/hhmer_Tx_hits.csv"
paste "${output_dir}"/*_grep.txt >> "${output_dir}/hhmer_Tx_hits.csv"

echo "hhmer_Tx_hits.csv created successfully at ${output_dir}."

# Step 5: Copy the CSV file one level up from the script's directory and rename it
new_file="${parent_script_dir}/hhmer_Tx_fam_hits.csv"
cp "${output_dir}/hhmer_Tx_hits.csv" "$new_file"

# Step 6: Remove "_aln" from the column headers in the new CSV file
echo "Updating column headers of $new_file to remove '_aln'..."
header_line=$(head -n 1 "$new_file")
updated_header=$(echo "$header_line" | sed 's/_aln//g')
sed -i "1s/.*/$updated_header/" "$new_file"

echo "Updated file saved to $new_file"

# Step 7: Extract sequences from the FASTA file for each family
echo "Extracting sequences for each family..."
for list_file in "${output_dir}"/*_grep.txt; do
    output_fasta="${list_file/_grep.txt/_grep.fasta}"  # Update FASTA naming
    seqkit grep -f "$list_file" "$fasta_file" -o "$output_fasta"
    echo "Extracted sequences saved to: $output_fasta"
done

# Step 8: Generate stats file for ORF counts per toxin family
stats_file="${parent_script_dir}/hhmer_Tx_fam_hits_stats.txt"
echo "Generating stats file at ${stats_file}..."
awk -F'\t' '
NR==1 { for (i=1; i<=NF; i++) col[i]=$i }
NR>1 {
    for (i=1; i<=NF; i++) if ($i != "") count[col[i]]++
}
END {
    for (family in count) print family ": " count[family] " ORFs"
}' "$new_file" > "$stats_file"

echo "Stats file generated successfully: $stats_file"

echo "All processes completed successfully."

